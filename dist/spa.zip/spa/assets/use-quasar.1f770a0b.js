import{i as a,V as r}from"./index.8d77281e.js";function u(){return a(r)}export{u};
