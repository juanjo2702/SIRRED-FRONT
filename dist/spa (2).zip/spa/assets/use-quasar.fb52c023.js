import{i as a,V as r}from"./index.51e11f8e.js";function u(){return a(r)}export{u};
