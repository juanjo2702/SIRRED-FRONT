import{i as a,V as r}from"./index.4197e342.js";function u(){return a(r)}export{u};
